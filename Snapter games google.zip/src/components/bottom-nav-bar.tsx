
'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Upload, Gamepad, BarChart2, User as UserIcon, LogOut, Home, Heart, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUser, useAuth } from '@/firebase';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';

const allNavItems = [
  { href: '/', icon: Home, label: 'Browse', roles: ['user', 'developer'] },
  { href: '/wishlist', icon: Heart, label: 'Wishlist', roles: ['user', 'developer'] },
  { href: '/publish', icon: Upload, label: 'Publish', roles: ['developer'] },
  { href: '/my-apps', icon: Gamepad, label: 'Apps', roles: ['developer'] },
  { href: '/analytics', icon: BarChart2, label: 'Stats', roles: ['developer'] },
];

export default function BottomNavBar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  
  const userRole = user?.profile?.role || 'user';
  const navItems = allNavItems.filter(item => item.roles.includes(userRole));

  const handleSignOut = async () => {
    if (auth) {
      await auth.signOut();
      router.push('/');
    }
  };

  const getInitials = (email?: string | null) => {
    return email ? email.substring(0, 2).toUpperCase() : '??';
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-[100] h-16 w-full border-t bg-background/95 backdrop-blur-sm shadow-[0_-2px_10px_rgba(0,0,0,0.05)] flex justify-center">
      <div className="container flex h-full max-w-screen-xl items-center justify-around px-2">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              'flex flex-1 flex-col items-center justify-center gap-1 rounded-md p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground min-w-0',
              pathname === item.href && 'text-primary font-medium'
            )}
          >
            <item.icon className="h-5 w-5 sm:h-6 sm:w-6" />
            <span className="truncate text-[10px] sm:text-xs">{item.label}</span>
          </Link>
        ))}

        {isUserLoading ? (
           <div className="flex flex-1 flex-col items-center justify-center gap-1 p-1 text-muted-foreground min-w-0 animate-pulse">
             <div className="h-6 w-6 rounded-full bg-muted" />
             <div className="h-2 w-8 rounded-full bg-muted" />
           </div>
        ) : user ? (
          <div className="flex flex-1 justify-center">
            <DropdownMenu modal={false}>
              <DropdownMenuTrigger asChild>
                  <button className={cn('flex flex-col items-center justify-center gap-1 rounded-md p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground min-w-0 outline-none select-none h-full w-full', (pathname === '/account' || pathname === '/setup-profile') && 'text-primary font-medium' )}>
                      <Avatar className="h-5 w-5 sm:h-6 sm:w-6 border-2 border-transparent">
                          <AvatarImage src={user.photoURL || undefined} alt="User avatar" />
                          <AvatarFallback className="bg-primary/10 text-primary text-[10px]">{getInitials(user.email)}</AvatarFallback>
                      </Avatar>
                      <span className="truncate text-[10px] sm:text-xs">Account</span>
                  </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="z-[110] w-56 mb-2" align="end" side="top">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.profile?.displayName || 'My Account'}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/account" className="cursor-pointer">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        ) : (
            <Link
              href="/login"
              className={cn(
                'flex flex-1 flex-col items-center justify-center gap-1 rounded-md p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground min-w-0',
                pathname === '/login' && 'text-primary font-medium'
              )}
            >
              <UserIcon className="h-5 w-5 sm:h-6 sm:w-6" />
              <span className="truncate text-[10px] sm:text-xs">Login</span>
            </Link>
        )}
      </div>
    </nav>
  );
}
