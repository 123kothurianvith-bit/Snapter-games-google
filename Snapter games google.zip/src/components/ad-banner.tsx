
'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface AdBannerProps {
  className?: string;
  slot?: string;
}

export default function AdBanner({ className, slot = "general" }: AdBannerProps) {
  return (
    <div 
      className={cn(
        "my-6 flex h-32 w-full flex-col items-center justify-center rounded-xl border-2 border-dashed border-muted-foreground/20 bg-muted/30 p-4 text-center transition-colors hover:bg-muted/40",
        className
      )}
    >
      <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60">Advertisement</div>
      <div className="text-sm font-medium text-muted-foreground italic">
        {slot === "homepage" ? "Promoted: Discover new worlds in Aether Odyssey!" : 
         slot === "detail" ? "Check out other games from this genre!" : 
         "Your Ad Here - Support Snapter Games"}
      </div>
      <div className="mt-2 text-[9px] text-muted-foreground/40">Ad Network Placeholder</div>
    </div>
  );
}
