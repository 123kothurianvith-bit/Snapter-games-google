
'use client';

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { initiateEmailSignIn, initiateGitHubSignIn, initiateGoogleSignIn, initiatePasswordReset } from '@/firebase/non-blocking-login';
import { useAuth, useUser } from '@/firebase';

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address." }),
  password: z.string().min(6, { message: "Password must be at least 6 characters." }),
});

type FormValues = z.infer<typeof formSchema>;

function LoginComponent() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGitHubSubmitting, setIsGitHubSubmitting] = useState(false);
  const [isGoogleSubmitting, setIsGoogleSubmitting] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const { toast } = useToast();
  const auth = useAuth();
  const { user, isUserLoading } = useUser();
  const router = useRouter();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  useEffect(() => {
    if (!isUserLoading && user && !isGitHubSubmitting && !isGoogleSubmitting) {
      router.push('/');
    }
  }, [user, isUserLoading, router, isGitHubSubmitting, isGoogleSubmitting]);

  function onSubmit(values: FormValues) {
    if (!auth) return;
    setIsSubmitting(true);
    initiateEmailSignIn(auth, values.email, values.password);
  }

  async function onGitHubSignIn() {
    if (!auth) return;
    if (isGitHubSubmitting) return;

    setIsGitHubSubmitting(true);
    try {
      await initiateGitHubSignIn(auth);
    } catch (error: any) {
      toast({
        title: "GitHub Sign-In Failed",
        description: error.message || "Could not complete GitHub sign-in.",
        variant: "destructive",
      });
    } finally {
      setIsGitHubSubmitting(false);
    }
  }

  async function onGoogleSignIn() {
    if (!auth) return;
    if (isGoogleSubmitting) return;

    setIsGoogleSubmitting(true);
    try {
      await initiateGoogleSignIn(auth);
    } catch (error: any) {
      toast({
        title: "Google Sign-In Failed",
        description: error.message || "Could not complete Google sign-in.",
        variant: "destructive",
      });
    } finally {
      setIsGoogleSubmitting(false);
    }
  }

  async function onForgotPassword() {
    const email = form.getValues("email");
    if (!email || !z.string().email().safeParse(email).success) {
      toast({
        title: "Email Required",
        description: "Please enter your email address to reset your password.",
        variant: "destructive",
      });
      return;
    }

    if (!auth) return;
    setIsResetting(true);
    try {
      await initiatePasswordReset(auth, email);
      toast({
        title: "Reset Email Sent",
        description: "Check your inbox for instructions.",
      });
    } catch (error: any) {
      toast({
        title: "Reset Failed",
        description: error.message || "Could not send reset email.",
        variant: "destructive",
      });
    } finally {
      setIsResetting(false);
    }
  }

  if (isUserLoading || user) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-background px-4">
      <Card className="mx-auto w-full max-w-sm shadow-xl border-t-4 border-t-primary overflow-hidden">
        <CardHeader className="pt-10 pb-4 text-center">
          <CardTitle className="text-3xl font-bold tracking-tight">Welcome Back</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-3">
            <Button
              className="w-full bg-[#24292F] text-white hover:bg-[#24292F]/90 rounded-md py-6 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 overflow-hidden"
              onClick={onGitHubSignIn}
              disabled={isSubmitting || isGitHubSubmitting || isGoogleSubmitting}
            >
              <svg className="h-5 w-5 shrink-0 fill-current" viewBox="0 0 24 24" aria-hidden="true">
                <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.65.003 1.305.088 1.916.258 1.91-1.295 2.75-1.026 2.75-1.026.545 1.378.202 2.397.1 2.65.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
              </svg>
              <span className="text-sm sm:text-base font-semibold truncate">Sign in with GitHub</span>
            </Button>

            <Button
              className="w-full bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 rounded-md py-6 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 overflow-hidden"
              onClick={onGoogleSignIn}
              disabled={isSubmitting || isGitHubSubmitting || isGoogleSubmitting}
            >
              <svg className="h-5 w-5 shrink-0" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
              <span className="text-sm sm:text-base font-semibold truncate">Sign in with Google</span>
            </Button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <Separator />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or with email</span>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="name@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-center">
                <Button
                  type="button"
                  variant="link"
                  className="text-xs text-muted-foreground h-auto p-0 hover:text-primary transition-colors"
                  onClick={onForgotPassword}
                  disabled={isResetting}
                >
                  {isResetting ? "Sending..." : "Forgot password?"}
                </Button>
              </div>

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full py-6 text-base font-semibold" disabled={isSubmitting || isGitHubSubmitting || isGoogleSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Login
              </Button>
            </form>
          </Form>

          <div className="mt-4 text-center text-sm pb-4">
            Don't have an account?{" "}
            <Link href="/signup" className="font-semibold text-primary hover:underline">
              Sign up
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function LoginPage() {
  return <LoginComponent />;
}
