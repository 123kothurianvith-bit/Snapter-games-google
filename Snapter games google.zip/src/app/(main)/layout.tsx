
'use client';

import React, { Suspense, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import BottomNavBar from '@/components/bottom-nav-bar';
import GameSearch from '@/components/game-search';
import { ThemeToggle } from '@/components/theme-toggle';
import { useCollection } from '@/firebase/firestore/use-collection';
import { useFirestore, useMemoFirebase, useUser } from '@/firebase';
import { collection } from 'firebase/firestore';

interface PublishedGame {
  id: string;
  gameName: string;
}

function MainLayoutContent({ children }: { children: React.ReactNode }) {
    const firestore = useFirestore();
    const { user, isUserLoading } = useUser();
    const pathname = usePathname();
    const router = useRouter();

    useEffect(() => {
      if (!isUserLoading && user && !user.profile?.displayName && pathname !== '/setup-profile') {
        router.push('/setup-profile');
      }
    }, [user, isUserLoading, pathname, router]);

    const publishedGamesQuery = useMemoFirebase(() => {
        if (!firestore) return null;
        return collection(firestore, 'publishedGames');
    }, [firestore]);

    const { data: games } = useCollection<PublishedGame>(publishedGamesQuery);

    const gameNames = React.useMemo(() => games?.map(g => g.gameName) || [], [games]);

  return (
      <div className="relative flex min-h-screen w-full flex-col bg-background overflow-x-hidden items-center">
        <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/95 backdrop-blur-sm h-16 flex justify-center">
          <div className="container flex h-full max-w-screen-xl items-center gap-4 px-4">
            <Link href="/" className="flex items-center gap-2 shrink-0">
              <span className="bg-gradient-to-r from-primary to-blue-500 bg-clip-text text-xl font-bold text-transparent">
                Snapter Games
              </span>
            </Link>
            <div className="relative flex flex-1 items-center gap-2">
                <Suspense fallback={<div className="h-10 w-full animate-pulse rounded-lg bg-muted" />}>
                  <GameSearch gameNames={gameNames}/>
                </Suspense>
                <ThemeToggle />
            </div>
          </div>
        </header>

        {/* Header spacer */}
        <div className="h-16 w-full shrink-0" />

        <main className="flex-1 w-full pb-20 flex justify-center">
          <div className="container max-w-screen-xl py-6 px-4">
            {children}
          </div>
        </main>
        
        <BottomNavBar />
      </div>
  );
}


export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <MainLayoutContent>{children}</MainLayoutContent>
  );
}
