
'use client';

import './globals.css';
import { WishlistProvider } from '@/contexts/wishlist-context';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from '@/components/theme-provider';
import SplashScreen from '@/components/splash-screen';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import Script from 'next/script';

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
          rel="stylesheet"
        />
        {/* Ad Network Scripts - Placed as high as possible in the head */}
        <Script 
          id="aclib-init"
          src="https://www.aclib.com/aclib.js"
          strategy="beforeInteractive"
        />
        <Script id="aclib-auto-tag" strategy="beforeInteractive">
          {`
            window.aclib = window.aclib || {};
            if (window.aclib.runAutoTag) {
              window.aclib.runAutoTag({
                zoneId: 'okfiaiqbxb',
              });
            }
          `}
        </Script>
      </head>
      <body className="font-body antialiased overflow-x-hidden">
        <ThemeProvider attribute="class" defaultTheme="dark">
            <FirebaseClientProvider>
                {isLoading && <SplashScreen onAnimationComplete={() => setIsLoading(false)} />}
                <div className={cn("transition-opacity duration-500 min-h-screen flex flex-col w-full overflow-x-hidden", isLoading ? "opacity-0" : "opacity-100")}>
                    <WishlistProvider>
                        {children}
                    </WishlistProvider>
                    <Toaster />
                </div>
            </FirebaseClientProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
