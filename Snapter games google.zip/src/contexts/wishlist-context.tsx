
"use client";

import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { useFirestore, useUser, useMemoFirebase, useDoc } from '@/firebase';
import { doc, setDoc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

interface WishlistContextType {
  wishlist: string[];
  addToWishlist: (gameId: string) => void;
  removeFromWishlist: (gameId: string) => void;
  isWishlisted: (gameId: string) => boolean;
  isLoading: boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider = ({ children }: { children: ReactNode }) => {
  const { user, isUserLoading: isAuthLoading } = useUser();
  const firestore = useFirestore();

  const wishlistDocRef = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    // Using a 'default' wishlist document for the user
    return doc(firestore, 'users', user.uid, 'wishlists', 'default');
  }, [firestore, user]);

  const { data: wishlistDoc, isLoading: isWishlistLoading } = useDoc(wishlistDocRef);

  const wishlist = wishlistDoc?.gameIds || [];

  const addToWishlist = (gameId: string) => {
    if (!user || !wishlistDocRef) return;

    const updateData = {
      id: 'default',
      userAccountId: user.uid,
      gameIds: arrayUnion(gameId)
    };

    setDoc(wishlistDocRef, updateData, { merge: true })
      .catch(async (error) => {
        if (error.code === 'permission-denied') {
          errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: wishlistDocRef.path,
            operation: 'write',
            requestResourceData: updateData,
          }));
        }
      });
  };

  const removeFromWishlist = (gameId: string) => {
    if (!user || !wishlistDocRef) return;

    const updateData = {
      gameIds: arrayRemove(gameId)
    };

    updateDoc(wishlistDocRef, updateData)
      .catch(async (error) => {
        if (error.code === 'permission-denied') {
          errorEmitter.emit('permission-error', new FirestorePermissionError({
            path: wishlistDocRef.path,
            operation: 'update',
            requestResourceData: updateData,
          }));
        }
      });
  };

  const isWishlisted = (gameId: string) => {
    return wishlist.includes(gameId);
  };

  return (
    <WishlistContext.Provider value={{ 
      wishlist, 
      addToWishlist, 
      removeFromWishlist, 
      isWishlisted,
      isLoading: isAuthLoading || isWishlistLoading
    }}>
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};
